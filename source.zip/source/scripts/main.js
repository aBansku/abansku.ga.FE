const onDownloadsClick = () => {
  window.location.href = './pages/downloads.html';
};
const onYoutubeClick = () => {
  window.location.href = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
};
const onGithubClick = () => {
  window.location.href = 'https://github.com/aBansku';
};
