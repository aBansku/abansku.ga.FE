const onBackClick = () => {
  window.location.href = '/index.html';
};
const onGamesClick = () => {
  window.location.href = '/pages/downloads/games.html';
};
const onMiscClick = () => {
  window.location.href = '/pages/downloads/misc.html';
};
