const download = () => {
  window.location.href = 'https://abansku.itch.io/kkeksi';
};
const downloadAki = () => {
  window.location.href = 'https://abansku.itch.io/akishooter';
};
const onBackClick = () => {
  window.location.href = '/pages/downloads.html';
};
