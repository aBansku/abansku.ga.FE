const onFortniteClick = () => {
  window.location.href = '/fortnite.exe';
};
const onBackClick = () => {
  window.location.href = '/pages/downloads.html';
};
const onYesClick = () => {
  window.location.href = '/yes.exe';
};
const onSourceClick = () => {
  window.location.href = '/source.zip';
};
